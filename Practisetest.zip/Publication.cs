﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practisetest
{
    class Publication
    {
        public string name { get; set; }
        public float price { get; set; }

        public Publication(string name, float price){
            this.name = name;
            this.price = price;
            }

        public override string ToString()
        {
            return $"title is {name} and the price is{price}";
        }
    }
}
