﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practisetest
{
    class TestPublication
    {
        static void Main(string[] args)
        {
            

            try
            {
                Console.WriteLine("enter the publication name");
                string pname = Console.ReadLine();
                Console.WriteLine("enter the price");
                float price = float.Parse(Console.ReadLine());
                Console.WriteLine("enter the author name");
                string aname = Console.ReadLine();
                Console.WriteLine("enter the page count");
                int pcount = int.Parse(Console.ReadLine());
                Console.WriteLine("enter the video timing");
                int vtime = int.Parse(Console.ReadLine());

                Books b = new Books("Treasure Hunt", 123, 23,"King");
                Videos v = new Videos("FF10", 150, 100);

                Console.WriteLine(b.ToString());
                Console.WriteLine(v.ToString());
                
            }

            catch(FormatException ex)
            {
                Console.WriteLine(ex.Message);

            }

            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
