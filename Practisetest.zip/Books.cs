﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practisetest
{
    class Books : Publication
    {
        public int pageCount { get; set; }
        public string author  { get; set; }


        public Books(string name, float price,int pcount, string author):base(name,price)
        {
            this.pageCount = pcount;
            this.author = author;
        }
        public override string ToString()
        {
            return base.ToString()+ $"pageCount of book is {pageCount} and the author is {author}";

        }
    }
}
