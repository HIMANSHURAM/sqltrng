﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practisetest
{
    class Videos : Publication
    {
        public int videoTime { get; set; }

        public Videos(string name,float price,int vtime):base(name,price)
        {
            this.videoTime = vtime;
        }

        public override string ToString()
        {
            return base.ToString()+$" video time of this collections is {videoTime}";
        }
    }
}
