﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises
{
    class Circle
    {
        double radius;

        public Circle(double v)
        {
            this.radius = 0;
        }

        public Circle()
        {
        }

        public void setRadius(double radius)
        {
            this.radius = radius;
        }

        public string getRadius()
        {
            return $"Radius of the circle is {this.radius}";
        }

        public string calcDiameter()
        {
            double diameter = 2*(this.radius);
            return $"the diameter of this circle is {diameter} units";
        }

        public string calcArea()
        {
            double area = Math.PI * this.radius * this.radius;
            return $"Area of this circle is {area} sq. units";
        }
    }

    class TestCircle
    {
        static void Main(string[] args)
        {
            Circle c = new Circle();
            c.setRadius(2);
            Console.WriteLine(c.getRadius());
            Console.WriteLine(c.calcDiameter());
            Console.WriteLine(c.calcArea());
        }
    }
}
