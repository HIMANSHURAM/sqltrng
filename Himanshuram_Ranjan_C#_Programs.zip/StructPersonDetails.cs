﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



//Write a program using structures that will get input regarding name, sex, height, 
//    weight and displays the information that is got from the user.


namespace Exercises
{
    class StructPersonDetails
    {
        public string name { get; set; }
        public string sex { get; set; }
        public double height { get; set; }

        public double weight { get; set; }
        

        public StructPersonDetails(string name, string sex, double height, double weight)
        {
            this.name = name;
            this.sex = sex;
            this.weight = weight;
            this.height = height;

        }

        public StructPersonDetails()
        {

        }

        public override string ToString()
        {
            return $"Name : {this.name} sex : {this.sex} height : {this.height} weight : {this.weight}";
        }
    }

    class TestStructPerson
    {
        static void Main(string[] args)
        {
            StructPersonDetails p;

            Console.WriteLine("Enter your name,sex,height,weight in each line");
            string name = Console.ReadLine();
            string sex = Console.ReadLine();
            double height = double.Parse(Console.ReadLine());
            double weight = double.Parse(Console.ReadLine());

            p = new StructPersonDetails(name,sex,height,weight);
            Console.WriteLine(p.ToString());
        }
    }
}
