﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class RandomNum
    {
        static void Main(string[] args)
        {
            Random r = new Random();

            Console.WriteLine("Some random numbers are");

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(r.Next());
            }
        }
    }
}
