﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



//Write a pgm that has class dimension and has two co-ordinates x, y and ‘area()’ as virtual method.
//    Now write different shape classes such a circle, cylinder and sphere that inherit the dimension class 
//    and calculate the surface area for each of them. Each derived class must have its own overrided 
//    implementation of method ‘area()’.
//    The pgm must display the respective area of the shapes by implementing the area()


namespace Exercises
{
    class Dimension
    {
        public float x { get; set; }
        public float y { get; set; }


        public Dimension()
        {

        }
        public virtual double calcArea()
        {
            return this.x * this.y;
        }
    }

    class Circle1 : Dimension
    {
        public double radius { get; set; }

        public Circle1(double radius)
        {
            this.radius = radius;
        }

        public override double calcArea()
        {
            return Math.PI*this.radius*Math.PI;
        }
    }

    class Sphere : Dimension
    {
        public double radius { get; set; }

        public Sphere(double raius)
        {
            this.radius = radius;
        }

        public override double calcArea()
        {
            return 4 * Math.PI * this.radius * this.radius;

        }
    }

    class Cylinder : Dimension
    {
        public double radius { get; set; }
        public  double height { get; set; }

        public Cylinder(double radius, double height)
        {
            this.radius = radius;
            this.height = height;
        }

        public override double calcArea()
        {
            return 2 * Math.PI * this.radius * this.height + 2 * Math.PI * Math.Pow(this.radius, 2);

        }
    }


    class TestDimesion
    {
        static void Main(string[] args)
        {
            Circle1 c = new Circle1(2.2);
            Console.WriteLine(c.calcArea());

            Cylinder cl = new Cylinder(12.3, 4);
            Console.WriteLine(cl.calcArea());
        }
    }
}
