﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//The majorant of an array of size N is a value that occurs in it at least N/2 + 1 times.
//    Write a program that finds the majorant of given array and prints it.
//    If it does not exist, print "The majorant does not exist!".
namespace Exercises
{
    class Majorant
    {
        static void Main(string[] args)
        {
            Dictionary<int, int> d = new Dictionary<int, int>();
            HashSet<int> hs = new HashSet<int>();
            int size = 0;

            Console.WriteLine("enter your inputs");
            while (true)
            {
                string inp = Console.ReadLine();
                if (inp.Equals(""))
                    break;

                int num = int.Parse(inp);

                if (d.ContainsKey(num))
                {
                    d[num] = d[num] + 1;
                }
                else
                {
                    d.Add(num, 1);
                }

                size++;
            }

            foreach (int i in d.Keys)
            {
                if (d[i] >= (size/2)+1)
                    hs.Add(i);
            }

            if (hs.Count == 0)
                Console.WriteLine("No majorant(s) are present");
            else
            {
                Console.WriteLine("majorants are ");
                foreach (int i in hs)
                {
                    Console.WriteLine(i);
                }
            }
            
        }
    }
}
