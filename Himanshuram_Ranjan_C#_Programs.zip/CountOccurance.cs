﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//Write a program that finds in a given array of integers (in the range [0…1000])
// how many times each of them occurs.

namespace Exercises
{
    class CountOccurance
    {
        static void Main(string[] args)
        {
            Dictionary<int, int> d = new Dictionary<int, int>();
            List<int> li = new List<int>();


            Console.WriteLine("enter your inputs");
            while (true)
            {
                string inp = Console.ReadLine();
                if (inp.Equals(""))
                    break;

                int num = int.Parse(inp);

                if (d.ContainsKey(num))
                {
                    d[num] = d[num] + 1;
                }
                else
                {
                    d.Add(num, 1);
                }
            }


            foreach(int i in d.Keys)
            {
                Console.WriteLine(i + " -> " + d[i] + " times");
            }
        }
    }
}
