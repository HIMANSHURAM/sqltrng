﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class Even
    {
        static void Main(string[] args)
        {
            int num;

            Console.WriteLine("Enter any number");
            num = int.Parse(Console.ReadLine());

            if(num%2==0)
            {
                Console.WriteLine($"{num} is an even number");
            }

            else
            {
                Console.WriteLine($"{num} is a odd number");
            }

        }
    }
}
