﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//Write a program using a class that get information about employee rollno, name, address, pin code, phone number,
//gross salary and pf. Display the net salary (ie gross less pf) and calculate grade base on net salary. The grades are
//Grade-‘A’ sal>10000
//Grade-‘B’ sal>5000
//Grade-‘C’ sal<5000
namespace Exercises
{
    class EmpGrade
    {

        public EmpGrade(int empNum, string name, string address, int pincode, string phoneNum, int grossSal,int pf)
        {
            this.empNum = empNum;
            this.name = name;
            this.address = address;
            this.pincode = pincode;
            this.phoneNum = phoneNum;
            this.grossSal = grossSal;
            this.pf = pf;

        }
        public int empNum { get; set; }
        public string name { get; set; }
        public string address { get; set; }

        public int pincode { get; set; }

        public string phoneNum { get; set; }

        public int grossSal { get; set; }
        public int pf { get; set; }

        public string Grade()
        {
            int netSal = this.grossSal - this.pf;

            if (netSal > 10000)
                return "Grade-A";
            else if (netSal > 5000)
                return "Grade-B";
            return "Grade-C";
        }
    }

    class TestEmpGrade
    {
        static void Main(string[] args)
        {
            EmpGrade emp = new EmpGrade(1213, "Raj", "Bangalore, India", 560019, "100-2324-231", 3000000, 100000);
            Console.WriteLine(emp.Grade());
        }
    }
}
