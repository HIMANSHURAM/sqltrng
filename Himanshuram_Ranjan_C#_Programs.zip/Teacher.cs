﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises
{
    class Teacher : Person
    {
        //string[] batches;
        Batch[] batches;    //containment
        string[] skills;
        public Teacher()
        {
            name = "noname";
            batches = new Batch[5];
            skills = new string[50];
        }

        public Teacher(string nam, DateTime d, Batch[] bat, string[] skill) : base(nam, d) //call base class constructor
        {
            this.batches = bat;
            this.skills = skill;
        }

        public string getBatch()
        {
            string res = "";
            foreach (Batch b in batches)
                res += b.ToString();
            return res;
        }
        public string Display()
        {
            return $"Name={this.name}, Birthday={this.Birthday()}, Skills={string.Join(",", this.skills)}, Batches={this.getBatch()}";
        }
    }



    class TestTeacher
    {
        public static void Main()
        {
            Teacher t1 = new Teacher("Roja", DateTime.Today,
                new Batch[] {
                    new Batch{Title="TTS-July2021",StartDate=DateTime.Today,EndDate=DateTime.Today,Trainees=29},  //object initializer
                    new Batch{Title="ETG-Aug2021",StartDate=DateTime.Today,EndDate=DateTime.Today,Trainees=22}
                },
                new string[] { "C#", "Azure", "Azure Devops" });

            //Console.WriteLine(t1.name);
            //Console.WriteLine(t1.BirthDay());

           // t1.setDOB(new DateTime(1990, 1, 10));

            Console.WriteLine(t1.Display());


        }
    }
}
