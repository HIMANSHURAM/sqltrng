﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Exercises
{
    class EmployeeSalary
    {
        int employeeId;
        public string name;
        int basicSalary;
        int hrAllow;
        int travelAllow;

        public EmployeeSalary()
        {
        }

        public EmployeeSalary(int employeeId,string name, int basicSalary, int hrAllow, int travelAllow)
        {
            this.employeeId = employeeId;
            this.name = name;
            this.basicSalary = basicSalary;
            this.hrAllow = hrAllow;
            this.travelAllow = travelAllow;
        }

        public string netTax()
        {
            int netSal = basicSalary + hrAllow + travelAllow;
            double totalTax = 0;
            if (netSal < 500000)
            {
                return $"Your net tax is {totalTax}";
            }
            
            else if(netSal>500000 && netSal < 1000000)
            {
                totalTax = (0.1) * netSal;
                return $"Your net tax is {totalTax}";
            }

            else if (netSal > 1000000 && netSal < 2000000)
            {
                totalTax = (0.2) * netSal;
                return $"Your net tax is {totalTax}";
            }

            else
            {
                totalTax = (0.3) * netSal;
                return $"Your net tax is {totalTax}";
            }
        }

    }

    class TestEmployeeSal
    {
        static void Main(string[] args)
        {
            EmployeeSalary e = new EmployeeSalary(1221, "Mohan", 700000, 100000, 20000);
            Console.WriteLine(e.netTax());
        }
        
    }
}
