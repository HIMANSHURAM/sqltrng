﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//Create a base class to take regno and name of students. Using inheritance, write a pgm that will take marks as input from the student.
//    Provide two branches science and commerce. If the student enters science then get the marks of physics, chemistry and math.
//    If the student enters commerce, get the marks for economics, accounts and banking. Then calculate the average of the three subjects.
//    The output should display regno, name, details of marks subject wise and the average of marks.
namespace Exercises
{
    abstract class StudentMarks
    {
        public string name { get; set; }

        public int rollNum { get; set; }

        public StudentMarks(string name, int rollNum)
        {
            this.name = name;
            this.rollNum = rollNum;

        }

        abstract public double calcAvg();
    }

    class Science : StudentMarks
    {
        public int physics { get; set; }
        public int maths { get; set; }

        public int chemistry { get; set; }

        public Science(string name,int rollNum,int phy,int maths,int chem) : base(name, rollNum)
        {
            this.physics = phy;
            this.maths = maths;
            this.chemistry = chem;
        }

        public override double calcAvg()
        {
            return (this.physics + this.maths + this.chemistry) / (3.0);
        }

        public override string ToString()
        {
            return $"name : {name},rollNUm : {rollNum}, phy : {physics}, maths : {maths}, chemistry : {chemistry}, avg is {calcAvg()}";
        }
    }

    class Commerce : StudentMarks
    {
        public int economics { get; set; }
        public int accounts { get; set; }

        public int banking { get; set; }

        public Commerce(string name,int rollNum,int eco,int acc,int bank) : base(name, rollNum)
        {
            this.economics = eco;
            this.accounts = acc;
            this.banking = bank;
        }

        public override double calcAvg()
        {
            return (this.banking + this.accounts + this.economics) / (3.0);
        }

        public override string ToString()
        {
            return $"name : {name}, rollNUm : {rollNum}, acc :{accounts}, banking : {banking}, economics : {economics}, avg is : {calcAvg()}";
        }
    }


    class TestStudentMarks
    {
        static void Main(string[] args)
        {
            string name;
            int rollNum;
            string branch;
            try
            {
                Console.WriteLine("Enter your name");
                name = Console.ReadLine();
                Console.WriteLine("Enter you roll no");
                rollNum = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter your branch");
                branch = Console.ReadLine();

                if (branch.Equals("Science"))
                {
                    Console.WriteLine("Enter your marks of physics, maths and chemistry");
                    int phy = int.Parse(Console.ReadLine());
                    int maths = int.Parse(Console.ReadLine());
                    int chem = int.Parse(Console.ReadLine());

                    Science sc = new Science(name, rollNum, phy, maths, chem);
                    Console.WriteLine(sc.ToString());

                }
                else
                {
                    Console.WriteLine("Enter your marks of physics, maths and chemistry");
                    int acc = int.Parse(Console.ReadLine());
                    int eco = int.Parse(Console.ReadLine());
                    int bank = int.Parse(Console.ReadLine());

                    Commerce cm = new Commerce(name, rollNum, eco, acc, bank);
                    Console.WriteLine(cm.ToString());
                }
            }
            catch(FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            finally
            {
                Console.WriteLine("Thank You!!!");
            }
        }
    }
}
