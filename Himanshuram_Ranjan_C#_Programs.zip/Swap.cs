﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class Swap
    {
        static void Main(string[] args)
        {
            int num1, num2, tem;

            Console.WriteLine("Enter your numbers");
            num1 = int.Parse(Console.ReadLine());
            num2 = int.Parse(Console.ReadLine());

            Console.WriteLine($"Before Swapping \n num1 is {num1} \n num2 is {num2}");
            tem = num1;
            num1 = num2;
            num2 = tem;

            Console.WriteLine($"After swapping \n num1 is {num1} \n num2 is {num2}");


        }
    }
}
