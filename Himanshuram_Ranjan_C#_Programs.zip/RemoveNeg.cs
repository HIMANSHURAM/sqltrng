﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Write a program, which removes all negative numbers from a sequence.

namespace Exercises
{
    class RemoveNeg
    {
        static void Main(string[] args)
        {
            List<int> li = new List<int>();
            List<int> lj = new List<int>();

            while (true)
            {
                string inp = Console.ReadLine();
                if (inp.Equals(""))
                {
                    break;
                }

                int num = int.Parse(inp);
                
                li.Add(num);
            }

            foreach (int i in li)
            {
                if (i > 0)
                {
                    lj.Add(i);
                }
            }

            // Console.WriteLine(li.Count);

            foreach (int i in lj)
                Console.WriteLine(i);
        }

    }
}
