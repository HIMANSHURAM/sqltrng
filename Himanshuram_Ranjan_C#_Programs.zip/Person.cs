﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises
{
    class Person
    {
        public string name;
        DateTime DOB;

        public Person()
        {
            name = String.Empty;
            DOB = DateTime.Today;
        }


        public Person(string name, DateTime DOB)
        {
            this.name = name;
            this.DOB = DOB;
        }

        public string Birthday()
        {
            return $"{this.name}'s Birthday is on {this.DOB:MMM} - {this.DOB.Day}";

        }

    }


    class TestPerson
    {
        static void Main(string[] args)
        {
            Person p = new Person("Mike",new DateTime(2000,1,1));
            
        }
    }
}
