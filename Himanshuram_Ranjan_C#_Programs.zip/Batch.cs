﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises
{
    class Batch
    {
        
        public string Title { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public int Trainees { get; set; }

        public override string ToString()
        {
            return $"title : {this.Title}, startDate : {this.StartDate}, endDate : {this.EndDate}, trainees :{this.Trainees}";
        }
    }
}
