﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



//Write a program, which reads from the console N integers and prints them in reversed order.
//    Use the Stack<int> class.

namespace Exercises
{
    class RevNum
    {
        static void Main(string[] args)
        {
            Stack<int> st = new Stack<int>();

            Console.WriteLine("enter your numers");
            while (true)
            {
                
                string inp = Console.ReadLine();

                if (inp.Equals(""))
                    break;

                int num = int.Parse(inp);
                st.Push(num);
            }

            Console.WriteLine("Reverse order");

            while (st.Count > 0)
                Console.WriteLine(st.Pop());

            
        }
    }
}
