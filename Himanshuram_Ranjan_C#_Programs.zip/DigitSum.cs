﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class DigitSum
    {
        static void Main(string[] args)
        {
            int num;
            int sum = 0;
            num = int.Parse(Console.ReadLine());

            while (num != 0)
            {
                sum += (num % 10);
                num /= 10;
            }

            Console.WriteLine(sum);
        }
    }
}
