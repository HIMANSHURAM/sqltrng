﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class Excep
    {
        static void Main(String[] arg)
        {
            int empid = 0;
            string empName = string.Empty;

            try
            {
                Console.WriteLine("enter your empid");
                empid = int.Parse(Console.ReadLine());

                Console.WriteLine("enter your name");
                empName = Console.ReadLine();

                Console.WriteLine($"Your name is {empName} and your empId is {empid}");
            }

            catch (FormatException ex)
            {
                Console.WriteLine("please enter only digits");
            }

            catch (OverflowException ex)
            {
                Console.WriteLine("please enter the empid in [1-30000]");
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            finally
            {
                Console.WriteLine("thanks for using the app!!!");
            }
        }
    }
}
