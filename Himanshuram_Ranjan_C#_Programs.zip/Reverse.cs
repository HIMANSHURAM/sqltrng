﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class Reverse
    {
        static void Main(string[] args)
        {
            int num;
            int revNum = 0;
            num = int.Parse(Console.ReadLine());

            while (num != 0)
            {
                revNum = (revNum * 10) + (num % 10);
                num /= 10;
            }

            Console.WriteLine("reversed number is; "+revNum);
        }
    }
}
