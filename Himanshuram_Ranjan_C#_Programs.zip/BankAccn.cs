﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises
{
    class BankAccn
    {
        int amount;

        public BankAccn()
        {
            this.amount = 500;
        }

        public BankAccn(int amount)
        {
            this.amount = amount;
        }

        public string getAmount()
        {
            return $"amount is = {this.amount}";
        }
    }


    class TestBank
    {
        static void Main(string[] args)
        {
            BankAccn ba = new BankAccn();
            Console.WriteLine(ba.getAmount());

            BankAccn bac = new BankAccn(1000);
            Console.WriteLine(bac.getAmount());
        }
    }
}
