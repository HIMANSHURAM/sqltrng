﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises
{

    public enum Status
    {
        single,
        married,
        divorced,
        widowed
    }

    class People
    {

        

        public People(string name, Status st, DateTime dob, string address)
        {
            this.name = name;
            this.st = st;
            this.dob = dob;
            this.address = address;

        }
        
        public string name  { get; set; }
        public DateTime dob { get; set; }
        public string address { get; set; }
        public Status st { get; set; }


        public int getAge()
        {
            DateTime now = DateTime.Today;
            int age = now.Year - dob.Year;
            if (dob > now.AddYears(-age)) 
                age--;  

            return age;
        }

        public Boolean canMarry()
        {
            if ((this.getAge()) > 18 && this.st!=Status.married)
                return true;
            return false;
        }

        public override string ToString()
        {
            string decision = canMarry() ? "can" : "can't";
            return $"{this.name} lives at {this.address} born on {this.dob.Date}, {this.st}, {this.getAge()} and {decision} marry";
        }

    }


    class TestPeople
    {
        static void Main(string[] args)
        {
            People p = new People("Harry", Status.married, new DateTime(2000, 12, 12), "London, UK");

            //Console.WriteLine(p.name);
            //Console.WriteLine(p.getAge());
            //Console.WriteLine(p.canMarry());
            Console.WriteLine(p.ToString());
        }
        
    }
}
