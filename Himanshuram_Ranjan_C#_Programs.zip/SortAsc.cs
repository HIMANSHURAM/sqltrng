﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//Write a program that reads from the console a sequence of positive integer numbers.
//    The sequence ends when an empty line is entered.
//    Print the sequence sorted in ascending order.

namespace Exercises
{
    class SortAsc
    {
        static void Main(string[] args)
        {
            SortedList<int, int> sl = new SortedList<int, int>();

            Console.WriteLine("Enter your numbers");
            while (true)
            {
                string inp = Console.ReadLine();

                if (inp.Equals(""))
                    break;

                sl.Add(int.Parse(inp), int.Parse(inp));
            }

            Console.WriteLine("Sorted List");
            foreach(int i in sl.Keys)
            {
                Console.WriteLine(i);
            }
        }
    }
}
