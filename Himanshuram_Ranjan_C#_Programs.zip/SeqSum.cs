﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//Write a program that reads from the console a sequence of positive integer numbers.
//    The sequence ends when empty line is entered.
//    Calculate and print the sum and the average of the sequence. Keep the sequence in List<int>.

namespace Exercises
{
    class SeqSum
    {
        static void Main(string[] args)
        {
            List<int> li = new List<int>();
            int sum = 0;
            int avg = 0;

            while (true)
            {
                string inp = Console.ReadLine();
                if (inp.Equals(""))
                {
                    break;
                }

                int num = int.Parse(inp);
                if (num > 0)
                    li.Add(num);
            }

            foreach(int i in li)
            {
                sum += i;
            }

            int count = li.Count;
            avg = sum / count;

            Console.WriteLine($"Sum of the numbers are {sum} and the average is {avg}");
        }
    }
}
