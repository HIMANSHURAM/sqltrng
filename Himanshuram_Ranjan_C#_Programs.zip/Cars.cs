﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//Write a pgm using interface that will get the name of the car as input and display it’s price.

namespace Exercises
{
    interface Cars
    {
        abstract public string getPrice();
    }

    class Honda : Cars
    {
        public string getPrice()
        {
            return "Price of Honds is Rs. 1000000";
        }
    }

    class Skoda : Cars
    {
        public string getPrice()
        {
            return "Price of Skoda is Rs. 1500000";
        }
    }

    class Benz : Cars
    {
        public string getPrice()
        {
            return "Price of Benz is Rs. 5000000";
        }
    }

    class TestClass
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Choose you car from : Honda, Skoda, Benz");
            string carName = Console.ReadLine();


            if (carName.Equals("Honda"))
            {
                Honda h = new Honda();
                Console.WriteLine(h.getPrice());
            }
            else if (carName.Equals("Benz"))
            {
                Benz h = new Benz();
                Console.WriteLine(h.getPrice());
            }

            else
            {
                Skoda h = new Skoda();
                Console.WriteLine(h.getPrice());
            }
               

        }
    }
}
