﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//Write a pgm that reads the age of a person. Validate the age and handle the errors.


namespace Exercises
{
    class PersonAge
    {
        static void Main(string[] args)
        {
            int age;
            try
            {
                Console.WriteLine("Enter your age");
                age = int.Parse(Console.ReadLine());

                Console.WriteLine($"Your age is {age}");
            }

            catch(FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }

            finally
            {
                Console.WriteLine("Thank you for using the app");
            }
        }
    }
}
